import React from 'react';
export default function AnaPanel() { return <div>Panel çalışıyor, can dostum!</div>; }
import React from 'react';
import AnaPanel from './AnaPanel';
export default function App() { return <AnaPanel />; }
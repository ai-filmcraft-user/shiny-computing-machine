import React from 'react';
export default function SceneEditor() { return <div>Sahne editörü</div>; }
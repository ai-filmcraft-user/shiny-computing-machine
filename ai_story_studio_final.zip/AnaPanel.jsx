import React from 'react';
export default function AnaPanel() { return <div>Ana Panel</div>; }